import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { 
  ListToolsRequestSchema, 
  CallToolRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
  ListRootsRequestSchema,
  CreateMessageRequestSchema
} from '@modelcontextprotocol/sdk/types.js';
// Using native fetch (Node 18+)

// Server configuration - support both old and new env var names
const RECALLIUM_SERVER_URL = process.env.RECALLIUM_SERVER_URL || process.env.RECALLIUM_SERVER_URL || 'http://localhost:8001/mcp';
const DEBUG = process.env.RECALLIUM_DEBUG === 'true' || process.env.MINIME_DEBUG === 'true';

// Logging helper
function log(...args) {
  if (DEBUG) {
    console.error('[Recallium MCP]', ...args);
  }
}

// Create the MCP server that communicates via stdio with Cursor
const server = new Server({
  name: "recallium",
  version: "1.2.4"
}, {
  capabilities: {
    tools: {},
    resources: {},
    prompts: {},
    sampling: {},
    roots: {
      listChanged: true
    }
  }
});

// Helper to make HTTP requests to Recallium server
async function callRecalliumServer(method, params = {}) {
  const requestBody = {
    jsonrpc: "2.0",
    method: method,
    params: params,
    id: Date.now().toString()
  };

  log(`Calling Recallium server: ${method}`, params);

  try {
    const response = await fetch(RECALLIUM_SERVER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'User-Agent': 'Recallium-MCP/1.2.4'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    
    if (result.error) {
      throw new Error(result.error.message || 'Unknown error');
    }

    log(`Response from Recallium:`, result.result);
    return result.result;
  } catch (error) {
    log(`Error calling Recallium:`, error);
    throw error;
  }
}

// Handle tool discovery
server.setRequestHandler(ListToolsRequestSchema, async () => {
  log('Handling tools/list request');
  return await callRecalliumServer('tools/list');
});

// Handle tool execution
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  log(`Handling tools/call request: ${name}`, args);
  return await callRecalliumServer('tools/call', { name, arguments: args });
});

// Handle resource listing
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  log('Handling resources/list request');
  return await callRecalliumServer('resources/list');
});

// Handle resource reading
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;
  log(`Handling resources/read request: ${uri}`);
  return await callRecalliumServer('resources/read', { uri });
});

// Handle prompt listing
server.setRequestHandler(ListPromptsRequestSchema, async () => {
  log('Handling prompts/list request');
  return await callRecalliumServer('prompts/list');
});

// Handle prompt retrieval
server.setRequestHandler(GetPromptRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  log(`Handling prompts/get request: ${name}`, args);
  return await callRecalliumServer('prompts/get', { name, arguments: args });
});

// Handle sampling requests
server.setRequestHandler(CreateMessageRequestSchema, async (request) => {
  log('Handling sampling/createMessage request');
  return await callRecalliumServer('sampling/createMessage', request.params);
});

// Handle roots listing
server.setRequestHandler(ListRootsRequestSchema, async () => {
  log('Handling roots/list request');
  return await callRecalliumServer('roots/list');
});

// Start the stdio transport
async function start() {
  log(`Starting Recallium MCP Client`);
  log(`Connecting to Recallium server at: ${RECALLIUM_SERVER_URL}`);
  
  // Test connection to Recallium server
  try {
    // Extract base URL (remove /mcp if present)
    const baseUrl = RECALLIUM_SERVER_URL.replace(/\/mcp$/, '');
    const response = await fetch(`${baseUrl}/health`);
    if (!response.ok) {
      console.error(`Warning: Recallium server at ${baseUrl} is not responding`);
      console.error(`Make sure your Docker container is running: docker run -p 8000:8000 recalliumai/recallium-community:latest`);
      console.error(`For help, visit: https://www.recallium.ai/help`);
    } else {
      log('Successfully connected to Recallium server');
    }
  } catch (error) {
    const baseUrl = RECALLIUM_SERVER_URL.replace(/\/mcp$/, '');
    console.error(`Warning: Cannot connect to Recallium server at ${baseUrl}`);
    console.error(`Error: ${error.message}`);
    console.error(`Make sure your Docker container is running: docker run -p 8000:8000 recalliumai/recallium-community:latest`);
    console.error(`For help, visit: https://www.recallium.ai/help`);
  }

  const transport = new StdioServerTransport();
  await server.connect(transport);
  
  log('MCP stdio transport connected');
}

// Handle errors gracefully
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start the server
start().catch(error => {
  console.error('Failed to start Recallium MCP Client:', error);
  process.exit(1);
});