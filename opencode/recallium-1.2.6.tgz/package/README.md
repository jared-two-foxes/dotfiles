# Recallium MCP Client

MCP (Model Context Protocol) client for connecting AI coding assistants to the [Recallium](https://recallium.ai) memory server.

## What is Recallium?

Recallium is a persistent memory system for AI coding assistants. It remembers your decisions, code patterns, and project context across sessions - so your AI assistant doesn't start from scratch every time.

## Quick Start

### 1. Start the Recallium server

```bash
git clone https://github.com/recallium-ai/recallium.git
cd recallium/install
chmod +x start-recallium.sh
./start-recallium.sh
```

### 2. Configure your AI assistant

**Cursor / Claude Desktop** (`~/.cursor/mcp.json` or `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "recallium": {
      "command": "npx",
      "args": ["-y", "recallium"],
      "env": {
        "RECALLIUM_SERVER_URL": "http://localhost:8001/mcp"
      }
    }
  }
}
```

### 3. Restart your AI assistant

The Recallium tools will now be available to your AI.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `RECALLIUM_SERVER_URL` | `http://localhost:8001/mcp` | URL of your Recallium server |
| `RECALLIUM_DEBUG` | `false` | Enable debug logging |

## Available Tools

Once connected, your AI assistant gains access to:

- **store_memory** - Save decisions, code snippets, and learnings
- **search_memories** - Find relevant past context
- **get_insights** - Analyze patterns across your work
- **session_recap** - Resume where you left off
- **projects** - Manage project briefs and documentation
- **tasks** - Track TODOs and action items
- **get_rules** - Load behavioral guidelines

## Links

- [Website](https://recallium.ai)
- [Help & Documentation](https://www.recallium.ai/help)
- [GitHub](https://github.com/recallium-ai/recallium)
- [Docker Hub](https://hub.docker.com/r/recalliumai/recallium-community)

## License

MIT
